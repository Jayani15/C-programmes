//program to read price of iphone and it's covercase and calculate bill
#include <stdio.h>

main()
{
    int p1,p2,bill;
    p1=p2=bill=0;
    
    printf("Enter the Price of IPhone : ");
    scanf("%d",&p1);
    
    printf("Enter the Price of Covercase : ");
    scanf("%d",&p2);
    
    bill = p1 + p2 ;
    
    printf("The Total Bill Amount is : %d",bill);
}
