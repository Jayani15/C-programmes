//Program to display gross salary and net salary from hra da and pf
#include <stdio.h>

main()
{
    int salary;
    float hra,da,pf,gross,net;
    salary=hra=da=pf=gross=net=0;
    
    printf("Enter Basic Salary : ");
    scanf("%d",&salary);
    
    hra = 0.2 * salary;
    da = 0.1 * salary;
    pf = 0.05 * salary;
    gross = salary + hra + da;
    net = gross - pf;
    
    printf("Gross Salary : %f",gross);
    printf("\nNet Salary : %f",net);

}
