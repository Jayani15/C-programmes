// Program to convert days into years months weeks and days
#include <stdio.h>

main()
{
    int tot,yr,mon,weeks,days;
    tot=yr=mon=weeks=days=0;
    
    printf("Enter Number of Days : ");
    scanf("%d",&tot);
    
    yr = tot/365;
    tot = tot - (yr * 365) ;
    mon = tot/30;
    tot = tot - (mon*30) ;
    weeks = tot/7;
    tot = tot - (weeks*7) ;
    days = tot;
    
    printf("Years : %d",yr);
    printf("\nMonths : %d",mon);
    printf("\nWeeks : %d",weeks);
    printf("\nDays : %d",days);
    
}
