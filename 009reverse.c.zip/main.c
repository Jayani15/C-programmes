//program to display 3 characters in reverse
#include <stdio.h>

main()
{
    char a,b,c;
    
    printf("Enter 3 characters of your choise : ");
    scanf("%c",&a);
    scanf("%c",&b);
    scanf("%c",&c);
    
    printf("Reverse of %c%c%c is %c%c%c",a,b,c,c,b,a);
}
