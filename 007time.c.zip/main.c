// Program to convert minutes to hours and minutes
#include <stdio.h>

main()
{
    int tot,hr,min;
    tot=hr=min=0;
    
    printf("Enter the Total Time Taken for Flying from Hyderabad to Singapore in minutes : ");
    scanf("%d",&tot);
    
    hr = tot/60;
    min = tot%60;
    
    printf("Flying Time from Hyderabad to Sinapore is %d hours and %d minutes",hr,min);
}
