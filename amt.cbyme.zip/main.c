// Program to calculate price of a item. Note the qty is a integer and the rate 1kg of the item is in fraction

#include<stdio.h>

int qty;
float rate,price;

main()
{
    //variable initialisation
    qty=rate=price=0;
    
    printf("Enter the quantity of item purchased : ");
    scanf("%d",&qty);
    
    printf("Enter the rate of 1kg of purchased item :");
    scanf("%f",&rate);
    
    //required calculation
    price = qty*rate;
    
    printf("The toatal Amount is : %f",price);
 
}