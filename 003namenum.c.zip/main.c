//Program to print name dob and mobile number
#include <stdio.h>

 main()
{
    char name[30],mon[10];
    int date,yr;
    long long int num;
    
    printf("Enter Your Name : ");
    scanf("%[^\n]",&name);
    
    printf("Enter Your date of birth(in the format month dd yyyy) : ");
    scanf("%s",&mon);
    scanf("%d",&date);
    scanf("%d",&yr);
    
    printf("Enter Your Mobile Number : ");
    scanf("%lld",&num);
    
    printf("\nYour Name is : %s",name);
    printf("\nYou DOB : %s %d,%d",mon,date,yr);
    printf("\nYour Mobile Number is : +91-%lld",num);
    
}
