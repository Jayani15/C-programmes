//Program to display balance amount to be returned to the customer
#include <stdio.h>

main()
{
    int bill,paid,balance;
    
    printf("Enter the Total Bill Amount : ");
    scanf("%d",&bill);
    
    printf("Enter the amount paid by the customer : ");
    scanf("%d",&paid);
    
    balance = paid - bill ;
    
    printf("Balance amount to be returned is : %d",balance);
    
}
